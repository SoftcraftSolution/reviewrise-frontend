require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const morgan    = require('morgan');
const { query } = require('./db');

const authRoutes   = require('./routes/auth');
const brandRoutes  = require('./routes/brands');
const couponRoutes = require('./routes/coupons');
const verifyRoutes = require('./routes/verify');
const miscRoutes   = require('./routes/misc');

const app = express();

app.use(cors({ origin: '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

app.use('/api/auth',    authRoutes);
app.use('/api/brands',  brandRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/verify',  verifyRoutes);
app.use('/api',         miscRoutes);

// Health
app.get('/health', (req, res) => res.json({ status:'ok', service:'ReviewRise API', time:new Date().toISOString() }));

// RESET ALL DATA — wipes brands/users (keeps superadmin)
app.post('/api/admin/reset-all', async (req, res) => {
  const { secret } = req.body;
  if (secret !== (process.env.RESET_SECRET || 'softcraft-reset-2024'))
    return res.status(403).json({ error: 'Wrong secret' });
  try {
    await query('DELETE FROM ad_views').catch(()=>{});
    await query('DELETE FROM qr_scans').catch(()=>{});
    await query('DELETE FROM verification_sessions').catch(()=>{});
    await query('DELETE FROM coupons').catch(()=>{});
    await query('DELETE FROM private_feedback').catch(()=>{});
    await query('DELETE FROM reviews').catch(()=>{});
    await query('DELETE FROM brand_visits').catch(()=>{});
    await query('DELETE FROM qr_codes').catch(()=>{});
    await query('DELETE FROM banners').catch(()=>{});
    await query('DELETE FROM ads').catch(()=>{});
    await query('DELETE FROM brands').catch(()=>{});
    await query("DELETE FROM users WHERE role != 'superadmin'").catch(()=>{});
    console.log('✅ All data reset');
    res.json({ success: true, message: 'All brands and dummy data wiped. Database is clean.' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.use((req, res) => res.status(404).json({ error: `Route ${req.method} ${req.path} not found` }));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: err.message }); });

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`\n⭐ ReviewRise API running on port ${PORT}\n`));
module.exports = app;
