const express = require('express');
const router  = express.Router();
const { v4: uuidv4 } = require('uuid');
const { query } = require('../db');
const { authenticate, requireBrandOwner, requireSuperAdmin } = require('../middleware/auth');

// ── GET /api/coupons ──────────────────────────────────────────
// Super admin: all coupons across platform
router.get('/', authenticate, requireSuperAdmin, async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, b.name as brand_name, b.emoji as brand_emoji
      FROM coupons c
      JOIN brands b ON c.brand_id = b.id
      ORDER BY c.issued_at DESC
      LIMIT 200
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/coupons/brand/:brandId ───────────────────────────
// Brand owner: their own coupons
router.get('/brand/:brandId', authenticate, requireBrandOwner, async (req, res) => {
  try {
    // Verify ownership
    if (req.user.role === 'brand_owner') {
      const check = await query('SELECT id FROM brands WHERE id = $1 AND owner_id = $2', [req.params.brandId, req.user.id]);
      if (!check.rows[0]) return res.status(403).json({ error: 'Not your brand' });
    }
    const result = await query(
      `SELECT * FROM coupons WHERE brand_id = $1 ORDER BY issued_at DESC`,
      [req.params.brandId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/coupons/my ────────────────────────────────────────
// Customer: their own coupons
router.get('/my', authenticate, async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, b.name as brand_name, b.emoji as brand_emoji
      FROM coupons c
      JOIN brands b ON c.brand_id = b.id
      WHERE c.user_id = $1
      ORDER BY c.issued_at DESC
    `, [req.user.id]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/coupons/verify ──────────────────────────────────
// Brand cashier verifies a coupon code
router.post('/verify', authenticate, requireBrandOwner, async (req, res) => {
  try {
    const { code, brand_id } = req.body;
    if (!code) return res.status(400).json({ error: 'Coupon code required' });

    // Expire old coupons first
    await query(`UPDATE coupons SET status = 'expired' WHERE expires_at < NOW() AND status = 'active'`);

    const result = await query(`
      SELECT c.*, b.name as brand_name, b.reward_offer
      FROM coupons c
      JOIN brands b ON c.brand_id = b.id
      WHERE UPPER(c.code) = UPPER($1)
    `, [code.trim()]);

    const coupon = result.rows[0];

    if (!coupon) {
      return res.json({ valid: false, reason: 'Coupon not found' });
    }
    if (coupon.status === 'redeemed') {
      return res.json({ valid: false, reason: 'Already redeemed', coupon });
    }
    if (coupon.status === 'expired') {
      return res.json({ valid: false, reason: 'Coupon has expired', coupon });
    }
    // Check brand match (brand owner can only verify coupons for their brand)
    if (req.user.role === 'brand_owner' && coupon.brand_id !== (brand_id || coupon.brand_id)) {
      return res.json({ valid: false, reason: 'Coupon is for a different brand' });
    }

    res.json({
      valid: true,
      coupon: {
        id:         coupon.id,
        code:       coupon.code,
        discount:   coupon.discount,
        min_order:  coupon.min_order,
        user_name:  coupon.user_name,
        user_email: coupon.user_email,
        source:     coupon.source,
        brand_name: coupon.brand_name,
        expires_at: coupon.expires_at,
        issued_at:  coupon.issued_at,
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/coupons/redeem ──────────────────────────────────
// Brand cashier marks coupon as redeemed after applying discount
router.post('/redeem', authenticate, requireBrandOwner, async (req, res) => {
  try {
    const { coupon_id, cashier_name } = req.body;
    if (!coupon_id) return res.status(400).json({ error: 'coupon_id required' });

    const result = await query(`
      UPDATE coupons
      SET status = 'redeemed',
          redeemed_at = NOW(),
          redeemed_by = $1
      WHERE id = $2 AND status = 'active'
      RETURNING *
    `, [cashier_name || 'Cashier', coupon_id]);

    if (!result.rows[0]) {
      return res.status(400).json({ error: 'Coupon already redeemed or not found' });
    }
    res.json({ success: true, coupon: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/coupons/generate ────────────────────────────────
// Brand owner generates a manual coupon
router.post('/generate', authenticate, requireBrandOwner, async (req, res) => {
  try {
    const { brand_id, discount, min_order, validity_days, for_user_name, for_user_email } = req.body;

    if (!brand_id || !discount) {
      return res.status(400).json({ error: 'brand_id and discount required' });
    }

    // Verify brand ownership
    if (req.user.role === 'brand_owner') {
      const check = await query('SELECT emoji FROM brands WHERE id = $1 AND owner_id = $2', [brand_id, req.user.id]);
      if (!check.rows[0]) return res.status(403).json({ error: 'Not your brand' });
    }

    // Generate unique code
    const brandEmoji = (await query('SELECT emoji FROM brands WHERE id = $1', [brand_id])).rows[0]?.emoji || '🏪';
    const prefix = brandEmoji.replace(/\s/g,'').toUpperCase().slice(0,3) || 'RR';
    let code, attempts = 0;
    do {
      code = prefix + Math.random().toString(36).toUpperCase().slice(2,8);
      const exists = await query('SELECT id FROM coupons WHERE code = $1', [code]);
      if (!exists.rows[0]) break;
      attempts++;
    } while (attempts < 10);

    const days = parseInt(validity_days) || 30;
    const result = await query(`
      INSERT INTO coupons (code, brand_id, user_name, user_email, discount, min_order, source, status, expires_at)
      VALUES ($1,$2,$3,$4,$5,$6,'manual','active', NOW() + INTERVAL '${days} days')
      RETURNING *
    `, [code, brand_id, for_user_name || 'Manual Coupon', for_user_email || '', discount, parseInt(min_order)||0]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Internal: issue coupon after verification ─────────────────
// Called by the verification service, not exposed publicly
const issueCouponForVerifiedReview = async (sessionId, userId, brandId) => {
  const brand = await query('SELECT * FROM brands WHERE id = $1', [brandId]);
  const b = brand.rows[0];
  if (!b) throw new Error('Brand not found');

  const user = await query('SELECT * FROM users WHERE id = $1', [userId]);
  const u = user.rows[0];

  // Check: user hasn't already gotten a coupon from a review for this brand in last 30 days
  const recentCoupon = await query(`
    SELECT id FROM coupons
    WHERE user_id = $1 AND brand_id = $2 AND source = 'review'
    AND issued_at > NOW() - INTERVAL '30 days'
  `, [userId, brandId]);

  if (recentCoupon.rows[0]) {
    return { alreadyIssued: true, code: recentCoupon.rows[0].code };
  }

  const prefix = b.emoji?.replace(/\s/g,'').slice(0,3).toUpperCase() || 'RR';
  const code = prefix + Math.random().toString(36).toUpperCase().slice(2,8);

  const result = await query(`
    INSERT INTO coupons (
      code, brand_id, user_id, user_name, user_email,
      discount, min_order, source, status, session_id,
      expires_at
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,'review','active',$8,
              NOW() + INTERVAL '${b.coupon_validity_days || 30} days')
    RETURNING *
  `, [code, brandId, userId, u?.name, u?.email, b.reward_offer, b.reward_min_order, sessionId]);

  return result.rows[0];
};

module.exports = router;
module.exports.issueCouponForVerifiedReview = issueCouponForVerifiedReview;
