require('dotenv').config();
const { query, pool } = require('./index');
const bcrypt = require('bcryptjs');

async function seed() {
  console.log('🌱 Seeding...\n');

  // Ensure password_hash column exists
  await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT`).catch(()=>{});

  const adminEmail = process.env.SUPERADMIN_EMAIL || 'admin@softcraftsolutions.in';
  const adminPass  = process.env.SUPERADMIN_PASSWORD || 'Admin@123';

  // ── SUPER ADMIN ────────────────────────────────────────────
  const aHash = await bcrypt.hash(adminPass, 10);
  const aRes  = await query(`
    INSERT INTO users (name, email, password_hash, role)
    VALUES ('SoftCraft Admin', LOWER($1), $2, 'superadmin')
    ON CONFLICT (email) DO UPDATE
      SET password_hash=EXCLUDED.password_hash, role='superadmin', name=EXCLUDED.name
    RETURNING id
  `, [adminEmail, aHash]);
  const adminId = aRes.rows[0].id;

  // ── BRAND OWNERS ───────────────────────────────────────────
  const brands_data = [
    { name:'Rajesh Kumar', email:'spice@gmail.com',  pass:'Spice@123',
      brand:{ name:'The Spice Garden', category:'Indian Restaurant', emoji:'🍛',
              location:'Connaught Place, Delhi', plan:'Pro', place:'ChIJN1t_tDeuEmsRUsoy',
              rating:4.7, reviews:847, scans:1240, offer:'20% OFF', min:500, days:30, phone:'+91 98765 43210' }},
    { name:'Anita Shah',   email:'brew@gmail.com',   pass:'Brew@123',
      brand:{ name:'Brew & Co.', category:'Café', emoji:'☕',
              location:'Hauz Khas, Delhi', plan:'Starter', place:'ChIJN2t_tDeuEmsRUsoy',
              rating:4.5, reviews:423, scans:780, offer:'15% OFF', min:300, days:20, phone:'+91 87654 32109' }},
    { name:'Priya Nair',   email:'style@gmail.com',  pass:'Style@123',
      brand:{ name:'Style Studio', category:'Salon', emoji:'💈',
              location:'Lajpat Nagar, Delhi', plan:'Pro', place:'ChIJN3t_tDeuEmsRUsoy',
              rating:4.6, reviews:312, scans:540, offer:'₹200 OFF', min:800, days:15, phone:'+91 76543 21098' }},
  ];

  const ownerIds  = [];
  const brandIds  = [];

  for (const d of brands_data) {
    const ph = await bcrypt.hash(d.pass, 10);
    const ur = await query(`
      INSERT INTO users (name, email, password_hash, role)
      VALUES ($1, LOWER($2), $3, 'brand_owner')
      ON CONFLICT (email) DO UPDATE
        SET password_hash=EXCLUDED.password_hash, name=EXCLUDED.name, role='brand_owner'
      RETURNING id
    `, [d.name, d.email, ph]);
    const uid = ur.rows[0].id;
    ownerIds.push(uid);

    // Check if brand exists for this owner
    const existing = await query(`SELECT id FROM brands WHERE owner_email=LOWER($1)`, [d.email]);
    if (existing.rows[0]) {
      await query(`UPDATE brands SET owner_id=$1 WHERE id=$2`, [uid, existing.rows[0].id]);
      brandIds.push(existing.rows[0].id);
      console.log(`✅ ${d.brand.name} — linked to owner`);
    } else {
      const br = await query(`
        INSERT INTO brands (owner_id,name,category,emoji,location,plan,google_place_id,
          google_rating,total_reviews,total_scans,reward_offer,reward_min_order,
          coupon_validity_days,owner_name,owner_email,owner_phone)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,LOWER($15),$16) RETURNING id
      `, [uid,d.brand.name,d.brand.category,d.brand.emoji,d.brand.location,
          d.brand.plan,d.brand.place,d.brand.rating,d.brand.reviews,d.brand.scans,
          d.brand.offer,d.brand.min,d.brand.days,d.name,d.email,d.brand.phone]);
      brandIds.push(br.rows[0].id);
      console.log(`✅ ${d.brand.name} — created`);
    }
  }

  const [bid1,bid2,bid3] = brandIds;
  const base = 'https://reviewrise-frontend.vercel.app/review?brand=';

  // QR codes (only if none exist)
  const qrCount = await query(`SELECT COUNT(*) as c FROM qr_codes WHERE brand_id=$1`, [bid1]);
  if (parseInt(qrCount.rows[0].c) === 0) {
    await query(`
      INSERT INTO qr_codes (brand_id,table_label,url,scan_count,created_by) VALUES
      ($1,'T1','${base}' || $1 || '&t=T1',120,$4),
      ($1,'T2','${base}' || $1 || '&t=T2',98,$4),
      ($2,'Counter','${base}' || $2 || '&t=counter',210,$4),
      ($3,'Reception','${base}' || $3 || '&t=reception',180,$4)
    `, [bid1,bid2,bid3,adminId]);
    console.log('✅ QR codes created');
  }

  // Ads (only if none)
  const adCount = await query(`SELECT COUNT(*) as c FROM ads`);
  if (parseInt(adCount.rows[0].c) === 0) {
    await query(`
      INSERT INTO ads (brand_id,title,description,active,views,clicks,created_by) VALUES
      ($1,'Spice Garden Grand Feast','Book a table for 4, get a complimentary dessert!',true,1240,310,$4),
      ($2,'Brew Morning Deal','Buy 2 coffees get 1 free every morning till 11am.',true,890,178,$4),
      ($3,'Style Studio New Look','Full makeover package starting ₹999 this weekend.',true,540,108,$4)
    `, [bid1,bid2,bid3,adminId]);
    console.log('✅ Ads created');
  }

  // Banners (only if none)
  const bnCount = await query(`SELECT COUNT(*) as c FROM banners`);
  if (parseInt(bnCount.rows[0].c) === 0) {
    await query(`
      INSERT INTO banners (brand_id,title,active,created_by) VALUES
      ($1,'Weekend Feast at Spice Garden',true,$4),
      ($2,'Morning Coffee Special',true,$4),
      ($3,'Glow Up at Style Studio',false,$4)
    `, [bid1,bid2,bid3,adminId]);
    console.log('✅ Banners created');
  }

  console.log('\n═══════════════════════════════════════════════');
  console.log('🎉 SEED COMPLETE — YOUR LOGIN CREDENTIALS:');
  console.log('═══════════════════════════════════════════════');
  console.log('\n🔐 SUPER ADMIN  →  /admin');
  console.log(`   Email:    ${adminEmail}`);
  console.log(`   Password: ${adminPass}`);
  console.log('\n🍛 Spice Garden →  /brand');
  console.log('   Email:    spice@gmail.com');
  console.log('   Password: Spice@123');
  console.log('\n☕ Brew & Co.   →  /brand');
  console.log('   Email:    brew@gmail.com');
  console.log('   Password: Brew@123');
  console.log('\n💈 Style Studio →  /brand');
  console.log('   Email:    style@gmail.com');
  console.log('   Password: Style@123');
  console.log('\n📱 Customer QR scan → /review?brand=<id>');
  console.log('   (Get brand IDs from Super Admin → Brands tab)');
  console.log('═══════════════════════════════════════════════\n');

  await pool.end();
}

seed().catch(err => {
  console.error('❌ Seed failed:', err.message);
  process.exit(1);
});
